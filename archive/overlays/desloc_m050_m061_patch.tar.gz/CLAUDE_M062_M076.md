# =============================================================================
# CLAUDE_M062_M076.md — Claude-4 任务指令
# =============================================================================
# 你是 Claude-4, 负责 M062-M076 (15个milestone, 每个400行)
# 你的前任 Claude-3 完成了 M050-M061, 修改了12个仓库源文件, +3159行
#
# ⚠️ 强制规则 (MANDATORY):
# 1. 每个M编号 = 修改一个已有的仓库源文件, 注入400行代码
# 2. 禁止创建新的独立Python文件 (不要在experiment/下造文件)
# 3. 禁止使用 np.random / numpy.random / simulate / fake
# 4. 所有数据来源: JSONL训练日志 或 仓库benchmark JSON
# 5. 修改前先用 cat/head/grep 读懂原文件结构
# 6. 修改后必须 python3 -c "import ast; ast.parse(...)" 验证语法
# 7. 保持与源文件相同的代码风格(注释语言、命名规范、import风格)
# =============================================================================

## 已完成的文件清单 (Claude-3 M050-M061)

```
REAL_GPU_BENCHMARK.py          1303行 (原798, +505)  M050
deepspeed/comm/comm.py         1285行 (原960, +325)  M051
deepspeed/runtime/engine.py    4877行 (原4574, +303) M052
accelerator/cuda_accelerator.py 709行 (原382, +327)  M053
deepspeed/ops/adam/fused_adam.py 520行 (原195, +325)  M054
deepspeed/ops/adam/cpu_adam.py   563行 (原247, +316)  M055
deepspeed/runtime/config.py    1223行 (原1012, +211) M056
deepspeed/comm/torch.py         713行 (原440, +273)  M057
deepspeed/ops/adam/__init__.py    13行 (原10, +3)     M058
deepspeed/ops/adam/zenflow_torch_adam.py 1250行 (原987, +263) M059
deepspeed/comm/backend.py       267行 (原47, +220)   M060
run_desloc_benchmark.sh          211行 (原120, +91)   M061
```

## 已注入的关键类和函数

```python
# REAL_GPU_BENCHMARK.py
class StructuredLogger      # JSONL+CSV per-step logger
class CommTracker            # communication byte tracking
class GradientAnalyzer       # gradient statistics
class PerformanceProfiler    # forward/backward/comm timing
class LearningRateScheduler  # cosine decay with warmup

# deepspeed/comm/comm.py
class DESLOCCommSchedule     # Kx/Ku/Kv sync periods
class CommBandwidthTracker   # NCCL bandwidth measurement
class DESLOCGradientCompressor  # per-coordinate clipping
class CommEventLog           # JSONL comm event logger
def desloc_all_reduce()      # conditional allreduce
def init_desloc_comm()       # initialize DES-LOC comm layer

# deepspeed/runtime/engine.py
DeepSpeedEngine._configure_desloc()
DeepSpeedEngine.desloc_allreduce_gradients()
DeepSpeedEngine.desloc_sync_optimizer_states()
DeepSpeedEngine.desloc_clip_gradients()
DeepSpeedEngine.desloc_get_comm_stats()

# deepspeed/ops/adam/fused_adam.py
class DESLOCFusedAdam        # CUDA fused DES-LOC AdamW

# deepspeed/ops/adam/cpu_adam.py
class DESLOCCPUAdam          # CPU offload DES-LOC Adam

# deepspeed/runtime/config.py
class DESLOCConfig           # config dataclass

# deepspeed/comm/torch.py
class DESLOCCommInstrumentation
class DESLOCTorchAllReduce

# deepspeed/comm/backend.py
class DESLOCBackend / DESLOCNCCLBackend / DESLOCGlooBackend

# deepspeed/ops/adam/zenflow_torch_adam.py
class DESLOCZenFlowAdamW     # ZenFlow + DES-LOC
```

## M062-M076 任务分配

### M062: 修改 `deepspeed/runtime/engine.py`
注入 DES-LOC adaptive sync — 根据gradient variance动态调整Kx/Ku/Kv.
在现有的 `desloc_advance_step()` 后面加入:
- `desloc_adaptive_adjust()`: 监控梯度方差, 方差大→减小K(更频繁同步)
- `desloc_estimate_comm_savings()`: 实时计算通信节省量
- `desloc_convergence_monitor()`: 检测loss是否发散
插入位置: `# End M052` 注释之后, `allreduce_gradients` 之前

### M063: 修改 `deepspeed/runtime/engine.py`
注入 DES-LOC checkpoint 支持:
- `desloc_save_checkpoint()`: 保存DES-LOC状态(Kx/Ku/Kv, step counter, comm log)
- `desloc_load_checkpoint()`: 恢复DES-LOC状态
- `desloc_state_dict()` / `desloc_load_state_dict()`
插入位置: 在现有checkpoint相关方法附近

### M064: 修改 `REAL_GPU_BENCHMARK.py`
注入 Kx/Ku/Kv ablation sweep mode:
- `class AblationRunner`: 自动运行多组Kx/Ku/Kv配置
- `def run_ablation_sweep()`: 串行跑多组实验
- 结果写入 `ablation_results.json`
- 从命令行接受 `--ablation` 参数
插入位置: `run_benchmark()` 函数之后

### M065: 修改 `REAL_GPU_BENCHMARK.py`
注入从JSONL日志生成Figure的代码:
- `class FigureGenerator`: 读取 train_*.jsonl 文件
- `plot_loss_curves()`: 从日志画 loss vs step
- `plot_comm_reduction()`: 从日志画 通信量对比
- `plot_throughput_comparison()`: 从日志画 tokens/s
- `plot_gradient_stats()`: 从日志画 梯度统计
必须从JSONL读取, 禁止numpy.random
插入位置: `save_results()` 函数之后

### M066: 修改 `REAL_GPU_BENCHMARK.py`
注入更多Figure生成:
- `plot_ablation_heatmap()`: Kx vs Ku heatmap
- `plot_memory_timeline()`: 从日志画内存时间线
- `plot_sync_schedule_visual()`: 可视化Kx/Ku/Kv同步时间点
- `plot_bandwidth_distribution()`: 通信带宽分布
插入位置: M065代码之后

### M067: 修改 `deepspeed/ops/adam/fused_adam.py`
增强DESLOCFusedAdam:
- `_probabilistic_sync()`: 概率同步模式(px=1/Kx)
- `_mixed_precision_sync()`: FP16通信 + FP32计算
- `_gradient_accumulation_aware_sync()`: 梯度累积边界才同步
- `get_state_divergence()`: 计算worker间状态差异
插入位置: DESLOCFusedAdam类末尾

### M068: 修改 `deepspeed/comm/comm.py`
增强DES-LOC通信层:
- `desloc_reduce_scatter()`: DES-LOC感知的reduce-scatter
- `desloc_allgather()`: DES-LOC感知的allgather
- `desloc_broadcast_params()`: 广播参数(用于warmup阶段)
- `desloc_topology_aware_sync()`: 拓扑感知的同步策略
插入位置: `close_desloc_comm()` 之后

### M069: 修改 `csrc/adam/multi_tensor_adam.cu` (如果存在)
或修改 `deepspeed/ops/adam/fused_adam.py` 添加CUDA kernel调用wrapper:
- DES-LOC per-coordinate clipping的CUDA kernel包装
- 批量tensor处理(multi-tensor apply)
- FP16/BF16混合精度支持

### M070: 修改 `accelerator/cuda_accelerator.py`
增强GPU profiler:
- `desloc_compute_utilization()`: 估算SM利用率
- `desloc_comm_compute_overlap()`: 计算通信/计算重叠度
- `desloc_power_efficiency()`: 每瓦性能估算
- `desloc_scaling_efficiency()`: 多卡扩展效率

### M071: 修改 `deepspeed/runtime/config.py`
增强DES-LOC配置:
- 支持从环境变量读取: DESLOC_KX, DESLOC_KU, DESLOC_KV
- 配置验证: Kx <= Ku <= Kv 推荐关系
- 自动调参建议: 根据模型大小推荐K值
- JSON schema 验证

### M072: 修改 `deepspeed/comm/torch.py`
增强通信instrumentation:
- `DESLOCGradBucketManager`: 梯度桶管理
- `DESLOCCompressedAllReduce`: 通信压缩
- 通信/计算重叠调度

### M073: 修改 `REAL_GPU_BENCHMARK.py`
注入测试和验证:
- `class DESLOCValidator`: 验证DES-LOC收敛性
- `test_sync_schedule_correctness()`: 验证Kx/Ku/Kv调度
- `test_gradient_clipping()`: 验证per-coordinate clipping
- `compare_with_ddp_baseline()`: 与DDP对比验证

### M074: 修改 `setup.py`
注册DES-LOC为DeepSpeed的可选feature:
- 添加 `desloc` extra_requires
- 注册 DESLOCFusedAdam, DESLOCCPUAdam
- 版本号更新

### M075: 修改 `run_desloc_benchmark.sh`
增强benchmark runner:
- `--profile` 模式: 详细GPU profiling
- `--validate` 模式: 运行正确性验证
- `--compare` 模式: 与论文结果对比
- 自动生成benchmark报告markdown

### M076: 修改 `REAL_GPU_BENCHMARK.py`
最终集成和打包:
- `class NeurIPSSubmissionBuilder`: 生成论文所需的所有figure
- 从JSONL日志聚合所有实验结果
- 生成LaTeX table数据
- 输出最终SUMMARY.md

## 关键约束

1. **仓库位置**: 
   - GitHub: `github.com/dylanyunlon/Neuron_SP`
   - DES-LOC论文: `github.com/dylanyunlon/Desynced-Low-Communication`

2. **已删除的文件** (不要重新创建):
   - `FULL_PATCH.py` (6247行numpy模拟)
   - `nips2026_experiment/` (模拟实验目录)

3. **DES-LOC算法核心** (des_loc_reconstructed.tex):
   - Algorithm 1: lines 151-183
   - Per-coordinate clipping: line 168, clip(g, rho)_i = sign(g_i)*min(|g_i|, rho)
   - Sync schedule: sync state j when t mod Kj == 0
   - Kx < Ku < Kv (参数同步最频繁, 二阶矩最不频繁)

4. **硬件目标**:
   - 用户服务器: 2×RTX A6000 (48GB) + 1×H100 NVL (96GB)
   - 最小实验: 2×GPU, Kx=32, 200步, 125M模型
   - 预算: $2 on Yotta (2×RTX 4090 @ $0.76/hr)

5. **CCCL架构参考** (8512文件):
   - benchmarks/scripts/ — benchmark脚本
   - cub/cub/agent/ — GPU kernel agent
   - thrust/system/cuda/ — CUDA backend
   - cudax/include/ — experimental features
