#!/bin/bash
# =============================================================================
# DES-LOC M050-M061 部署指南
# =============================================================================
# Claude-3 交付物: 12个文件, 3159行新增代码
# 目标仓库: github.com/dylanyunlon/Neuron_SP
# =============================================================================

# ==============================
# 1. 在服务器上解压并覆盖代码
# ==============================

# 先进入 Neuron_SP 仓库根目录
cd /path/to/Neuron_SP

# 解压 (会覆盖同名文件,保持目录结构)
tar xzf /path/to/desloc_m050_m061_patch.tar.gz -C .

# 验证文件
echo "=== 验证修改后的文件 ==="
for f in \
    REAL_GPU_BENCHMARK.py \
    run_desloc_benchmark.sh \
    deepspeed/comm/comm.py \
    deepspeed/comm/torch.py \
    deepspeed/comm/backend.py \
    deepspeed/runtime/engine.py \
    deepspeed/runtime/config.py \
    deepspeed/ops/adam/__init__.py \
    deepspeed/ops/adam/fused_adam.py \
    deepspeed/ops/adam/cpu_adam.py \
    deepspeed/ops/adam/zenflow_torch_adam.py \
    accelerator/cuda_accelerator.py; do
    echo "  $(wc -l < "$f") 行  $f"
done

# 语法检查
python3 -c "
import ast, sys
files = [
    'REAL_GPU_BENCHMARK.py',
    'deepspeed/comm/comm.py',
    'deepspeed/comm/torch.py',
    'deepspeed/comm/backend.py',
    'deepspeed/runtime/engine.py',
    'deepspeed/runtime/config.py',
    'deepspeed/ops/adam/__init__.py',
    'deepspeed/ops/adam/fused_adam.py',
    'deepspeed/ops/adam/cpu_adam.py',
    'deepspeed/ops/adam/zenflow_torch_adam.py',
    'accelerator/cuda_accelerator.py',
]
ok = 0
for f in files:
    try:
        ast.parse(open(f).read())
        ok += 1
    except SyntaxError as e:
        print(f'FAIL: {f}: {e}')
print(f'{ok}/{len(files)} files passed syntax check')
"

# ==============================
# 2. Git 提交
# ==============================

# 删除旧的模拟代码 (如果还在的话)
git rm -f FULL_PATCH.py 2>/dev/null || true
git rm -rf nips2026_experiment/ 2>/dev/null || true

# 添加所有修改的文件
git add \
    REAL_GPU_BENCHMARK.py \
    run_desloc_benchmark.sh \
    deepspeed/comm/comm.py \
    deepspeed/comm/torch.py \
    deepspeed/comm/backend.py \
    deepspeed/runtime/engine.py \
    deepspeed/runtime/config.py \
    deepspeed/ops/adam/__init__.py \
    deepspeed/ops/adam/fused_adam.py \
    deepspeed/ops/adam/cpu_adam.py \
    deepspeed/ops/adam/zenflow_torch_adam.py \
    accelerator/cuda_accelerator.py

# 提交
git commit -m "feat(desloc): M050-M061 DES-LOC engine integration — 3159 lines across 12 files

DES-LOC (Desynced Low Communication) optimizer integration into DeepSpeed fork.
All code modifies existing repository source files. Zero numpy simulation.

M050: REAL_GPU_BENCHMARK.py (+505 lines)
  - StructuredLogger: per-step JSONL+CSV training logs
  - CommTracker: real communication byte counting
  - GradientAnalyzer: gradient stats from actual param.grad tensors
  - PerformanceProfiler: forward/backward/comm/optim timing
  - LearningRateScheduler: cosine decay with warmup

M051: deepspeed/comm/comm.py (+325 lines)
  - DESLOCCommSchedule: Kx/Ku/Kv independent sync periods
  - CommBandwidthTracker: real NCCL bandwidth measurement
  - DESLOCGradientCompressor: per-coordinate clipping (Algorithm 1)
  - CommEventLog: JSONL communication event logging
  - desloc_all_reduce(): conditional allreduce API

M052: deepspeed/runtime/engine.py (+303 lines)
  - _configure_desloc(): engine-level DES-LOC initialization
  - desloc_allreduce_gradients(): skip allreduce when Kx not reached
  - desloc_sync_optimizer_states(): sync u/v at Ku/Kv intervals
  - desloc_clip_gradients(): per-coordinate clipping in engine
  - Modified allreduce_gradients() to route through DES-LOC

M053: accelerator/cuda_accelerator.py (+327 lines)
  - desloc_init_profiler(): GPU profiling state
  - desloc_memory_snapshot(): real-time HBM tracking
  - desloc_hbm_state_analysis(): optimizer state memory analysis
  - desloc_nccl_test(): real NCCL bandwidth measurement
  - desloc_topology_info(): GPU interconnect detection

M054: deepspeed/ops/adam/fused_adam.py (+325 lines)
  - DESLOCFusedAdam: CUDA kernel-fused DES-LOC AdamW
  - Per-coordinate gradient clipping (Algorithm 1 line 168)
  - Independent Kx/Ku/Kv sync via sync_if_needed()
  - Pure PyTorch fallback when CUDA kernel unavailable

M055: deepspeed/ops/adam/cpu_adam.py (+316 lines)
  - DESLOCCPUAdam: CPU-offload DES-LOC Adam for ZeRO-Offload
  - CPU↔GPU transfer for state synchronization
  - C++ kernel with Python fallback

M056: deepspeed/runtime/config.py (+211 lines)
  - DESLOCConfig: configuration dataclass with validation
  - JSON config parsing for desloc section
  - Helper functions: get_desloc_enabled/Kx/Ku/Kv/clip_radius

M057: deepspeed/comm/torch.py (+273 lines)
  - DESLOCCommInstrumentation: bandwidth/latency measurement
  - DESLOCTorchAllReduce: conditional allreduce wrapper
  - Per-operation skip tracking and statistics

M058: deepspeed/ops/adam/__init__.py (+3 lines)
  - Register DESLOCFusedAdam and DESLOCCPUAdam exports

M059: deepspeed/ops/adam/zenflow_torch_adam.py (+263 lines)
  - DESLOCZenFlowAdamW: ZenFlow selective update + DES-LOC sync
  - Combines compute reduction (ZenFlow) with comm reduction (DES-LOC)

M060: deepspeed/comm/backend.py (+220 lines)
  - DESLOCBackend: abstract DES-LOC communication backend
  - DESLOCNCCLBackend: NCCL implementation
  - DESLOCGlooBackend: Gloo/CPU implementation
  - DESLOCSingleGPUBackend: no-op for single GPU
  - create_desloc_backend(): factory function

M061: run_desloc_benchmark.sh (+91 lines)
  - Real GPU benchmark launcher (replaces FULL_PATCH.py reference)
  - Kx/Ku/Kv ablation sweep mode
  - Multi-GPU torchrun support

Deleted: FULL_PATCH.py (6247 lines of numpy simulation)
Deleted: nips2026_experiment/ (all simulation artifacts)

Reference: DES-LOC paper (ICLR 2026), Algorithm 1
Reference: des_loc_reconstructed.tex lines 147-200"

# 推送
git push origin main
